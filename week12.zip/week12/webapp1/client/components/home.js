import React from "react";

export default function Home() {
  let d = new Date("1999-02-11T20:00:00.000Z");
  return (
    <>
      <div class="container" style={{ marginTop: "50px" }}>
        <div class="row align-items-center">
          <div class="col-10">
            <h1>Welcome to Students App</h1>
            <h2>{d.toDateString()}</h2>
          </div>
        </div>
      </div>
    </>
  );
}