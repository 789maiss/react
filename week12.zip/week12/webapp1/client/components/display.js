import React, { useState, useEffect } from "react";
import axios from "axios";

export default function Display() {
    const [displayStudents, setDisplayStudents] = useState([]);

    useEffect(() => {
        const fetchData = async () => {
            try {
                const response = await axios.get("http://localhost:3003/display");
                setDisplayStudents(response.data);
            } catch (err) {
                console.log(err);
            }
        };

        fetchData();
    }, []);  

    console.log(displayStudents);
    
    return(
        <>
            <div class="container" style={{"marginTop" : "50px"}}>
                <div class="row align-items-center justify-content-center">
                    <div class="col-10">
                        <h1>Display</h1>
                        <table class="table table-striped table-bordered">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>ID</th>
                                    <th>NAME</th>
                                    <th>GENDER</th>
                                    <th>DOB</th>
                                    <th>DEPARTMENT</th>
                                    <th>EMAIL</th>
                                    <th>PASSWORD</th>
                                </tr>
                            </thead>
                            <tbody>
                                {
                                    displayStudents.map((student, index) => {
                                        let stuDateOfBirth = new Date(student.stuDOB).toDateString()
                                        return(
                                            <tr>
                                                <td>{index+1}</td>
                                                <td>{student.stuID}</td>
                                                <td>{student.stuName}</td>
                                                {
                                                 (student.stuGender)?<td>Male</td>:<td>Female</td>
                                                }
                                                <td>{stuDateOfBirth}</td>
                                                <td>{student.stuDept}</td>
                                                <td>{student.stuEmail}</td>
                                                <td>{student.stuPass}</td>
                                            </tr>
                                        )
                                    })
                                }
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </>
    )
}