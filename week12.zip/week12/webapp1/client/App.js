
/*
npx create-react-app .
npm install react-router-dom
npm install axios 
npm install bootstrap --save


to run your app
npm start

*/

import './App.css';
import React from "react";
import "bootstrap/dist/css/bootstrap.css";
import { BrowserRouter, Routes, Route, Link } from "react-router-dom";
import "axios";
import Home from "./components/home";
import Display from "./components/display";

function App() {
  return (
    <div className="App">
       <div class="container-fluid">
      <BrowserRouter>
        <nav class="nav-bar bg-light">
          <div class="container-fluid justify-content-end">
            <ul class="nav">
              <li class="nav-item">
                <Link to="/" class="nav-link">
                  HOME
                </Link>
              </li>
              <li class="nav-item">
                <Link to="/display" class="nav-link">
                  DISPLAY
                </Link>
              </li>
              <li class="nav-item">
                <Link to="/insert" class="nav-link">
                  INSERT
                </Link>
              </li>
              <li class="nav-item">
                <Link to="/search" class="nav-link">
                  SEARCH
                </Link>
              </li>
              <li class="nav-item">
                <Link to="/update" class="nav-link">
                  UPDATE
                </Link>
              </li>
              <li class="nav-item">
                <Link to="/delete" class="nav-link">
                  DELETE
                </Link>
              </li>
            </ul>
          </div>
        </nav>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/display" element={<Display />} />
        </Routes>
      </BrowserRouter>
    </div>
    </div>
  );
}

export default App;
