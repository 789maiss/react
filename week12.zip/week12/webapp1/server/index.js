import express from "express";
import mongoose from "mongoose";
import cors from "cors";



const myApp = express();

myApp.use(express.json());
myApp.use(cors());

const PORT = 3003;
const myDB = 'StudentsDB';

mongoose.connect(`mongodb+srv://admin:admin123@cluster0.vbxdj5k.mongodb.net/${myDB}`);

const mySchema = new mongoose.Schema({
    stuID: Number,
    stuName: String,
    stuGender: String,
    stuDOB: Date,
    stuDept: String,
    stuEmail: String,
    stuPass: String,
  });
  
  const myModel = mongoose.model("students_records", mySchema);

myApp.get("/display", async (req, res) => {
  try {
    const students = await myModel.find();
    res.json(students);
  } catch (err) {
    res.json(err);
  }
});

myApp.listen(PORT, () => {
  console.log("Server is Running ......!");
});
